from django.apps import AppConfig

class ChaptersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chapters'  # 确保这个名称正确